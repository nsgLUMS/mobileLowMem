echo
echo ----- CF-Auto-Root-bullhead-bullhead-nexus5x -----
echo
echo If you are on Android 5.0 or newer, please make sure the \"Allow OEM Unlock\"
echo option \(if present\) is enabled in \"Settings-\>Developer Options\".
echo
echo If you cannot find \"Developer Options\" under \"Settings\", first go to the
echo \"Settings-\>About\" screen, find the \"Build number\" entry, and tap it 7 times.
echo
echo ----- ----- ----- ----- ----- ----- -----
echo
echo Please make sure your device is in bootloader/fastboot mode before continuing.
echo
echo ----- ----- ----- ----- ----- ----- -----
echo
echo ***WARNING*** ALL YOUR DATA *MAY* BE WIPED ! ***WARNING***
echo
echo We are going to run the \"OEM UNLOCK\" command on your device. If your device
echo was not previously unlocked, this will wipe all your data !
echo
echo Please watch the screen on your device, user input may be required.
echo
echo You may need to enter your administrator password to continue.
echo
echo Press Ctrl+C to cancel !
echo
echo Press ENTER to continue
read
sudo chmod +x tools/fastboot-mac 1>/dev/null 2>/dev/null
sudo tools/fastboot-mac oem unlock 1>/dev/null 2>/dev/null
sudo tools/fastboot-mac oem unlock 1>/dev/null 2>/dev/null
sudo tools/fastboot-mac flashing unlock 1>/dev/null 2>/dev/null
sudo tools/fastboot-mac flashing unlock 1>/dev/null 2>/dev/null
echo
echo ----- ----- ----- ----- ----- ----- -----
echo
echo If you just unlocked for the first time, it is advised to boot the device into
echo Android before continuing. This first boot may take several minutes, sometimes
echo even half an hour.
echo
echo If you decide to boot back into Android first, return your device to 
echo bootloader/fastboot mode before continuing again.
echo
echo Press Ctrl+C to cancel !
echo
echo Press ENTER to continue
read
echo
echo ----- ----- ----- ----- ----- ----- -----
echo
echo We will now attempt to boot CF-Auto-Root. You should see a red Android on the
echo screen of your device in a minute, with scrolling white text on top of it.
echo
sudo tools/fastboot-mac boot image/CF-Auto-Root-bullhead-bullhead-nexus5x.img
echo
echo If nothing happens even after several minutes, something may be wrong.
echo
echo Once CF-Auto-Root is done, it will reboot your device. Keep in mind that your
echo device may reboot a number of times, and it may be a few minutes before you
echo are back into Android. It is important that you do not interrupt this process,
echo unless it takes more than five minutes in total.
echo
echo Press ENTER to continue
read
